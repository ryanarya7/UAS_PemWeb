<?php
$awal = 46;
$akhir = 69;

for($i=$awal; $i<=$akhir; $i=$i+2.5){
    $satu[]=$i;
}
print_r($satu);

?>